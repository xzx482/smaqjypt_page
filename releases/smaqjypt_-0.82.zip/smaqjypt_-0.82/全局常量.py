import json,os,re
from 终端控制 import 按任意键继续

数据文件目录="smaqjypt_数据/"

错误信息文件目录=数据文件目录+"错误信息/"
用户表文件目录	=数据文件目录+"用户表/"
用户数据文件	=数据文件目录+"用户信息.json"
专题id文件		=数据文件目录+"专题id表.json"
配置文件		=数据文件目录+'配置.json'



更新url=[
	"https://smaqjypt.github.xzx482.ml/",
	"https://xzx482.github.io/smaqjypt_page/",
	"https://raw.githubusercontent.com/xzx482/smaqjypt_page/main/"
]


弱密码列表=[
	'123456'
]

假登录=True

修改密码="123456aA"

修改密码匹配=re.compile('^(?=.*?[A-Za-z]+)(?=.*?[0-9]+)(?=.*?[A-Z]).*$')

教程_阶段=0

延迟=0

class 完成延迟:

	批量完成=5

	自动完成=10
	查询作业=10

	假登录=15
	假登录_修改密码=20

	完成安全学习_视频=.4
	完成安全学习_问题=30

	完成专题活动_签到=3
	完成专题活动_问卷_单题=3
	完成专题活动_问卷=4
	完成专题活动_检查=2
	#假期专题延迟与普通专题相同






初次使用=False

if(not os.path.isdir(数据文件目录)):

	#print('用户协议:')
	# if(input('若同意,输入"y"确认')!="y"):
	# 	exit()
	初次使用=True
	if(os.path.isfile(数据文件目录[0:-1])):
		按任意键继续('错误:无法创建文件夹"'+数据文件目录[0:-1]+'",该名称已被文件'+数据文件目录[0:-1]+'"占用,',提示信息_3='尝试删除')
		if(os.path.isfile(数据文件目录[0:-1])):
			os.remove(数据文件目录[0:-1])
	
	os.makedirs(数据文件目录[0:-1])
	
	
	with open(专题id文件,"w")as f:f.write("{}")
	
	with open(用户数据文件,"w")as f:f.write("{}")
	
	with open(配置文件,"w")as f:f.write("{}")
	

if(not os.path.isdir(错误信息文件目录)):
	if(os.path.isfile(错误信息文件目录[0:-1])):
		按任意键继续('错误:无法创建文件夹"'+错误信息文件目录[0:-1]+'",该名称已被文件'+错误信息文件目录[0:-1]+'"占用,',提示信息_3='尝试删除')
		if(os.path.isfile(错误信息文件目录[0:-1])):
			os.remove(错误信息文件目录[0:-1])
	
	os.makedirs(错误信息文件目录[0:-1])
	
	with open(错误信息文件目录+"问题反馈帮助.txt","w")as f:f.write("若要反馈问题,可反馈到邮箱1738078451@qq.com,标题为\"问题反馈\",在正文中描述问题是如何发生的,并将错误信息添加到附件中,错误信息不会包括个人信息")

if(not os.path.isdir(用户表文件目录)):
	if(os.path.isfile(用户表文件目录[0:-1])):
		按任意键继续('错误:无法创建文件夹"'+用户表文件目录[0:-1]+'",该名称已被文件'+用户表文件目录[0:-1]+'"占用,',提示信息_3='尝试删除')
		if(os.path.isfile(用户表文件目录[0:-1])):
			os.remove(用户表文件目录[0:-1])
	
	os.makedirs(用户表文件目录[0:-1])



完成延迟_={}

完d=完成延迟.__dict__
for i in 完d:
	if i[0:2]!='__'and i[-2:]!='__':
		完成延迟_[i]=完d[i]

class 完成延迟_c_:
	def __getattr__(s,i):
		return 完成延迟_[i]

完成延迟=完成延迟_c_()


配置={}
配置['完成延迟']=完成延迟_
配置['更新url']=更新url
配置['弱密码列表']=弱密码列表
配置['假登录']=假登录
配置['修改密码']=修改密码
配置['教程_阶段']=教程_阶段
配置['延迟']=延迟

配置文件o=open(配置文件,'a+')

def 更新():
	global 完成延迟_,更新url,假登录,弱密码列表,教程_阶段,延迟,修改密码
	完成延迟_	=配置['完成延迟']
	更新url		=配置['更新url']
	假登录		=配置['假登录']
	弱密码列表	=配置['弱密码列表']
	修改密码	=配置['修改密码']
	教程_阶段	=配置['教程_阶段']
	延迟		=配置['延迟']
	写入配置()

def 读取配置():
	global 配置
	配置文件o.seek(0)
	配置_=配置.copy()
	配置_.update(json.load(配置文件o))

	if not 修改密码匹配.match(配置_['修改密码']):
		print('注意: 密码"'+配置_['修改密码']+'"不符合要求, 已重置为"'+修改密码+'"')
		配置_['修改密码']=修改密码

	for i in 配置_:
		if isinstance(配置_[i],dict):
			配置[i].update(配置_[i])
		else:
			配置[i]=配置_[i]
	

	更新()

def 写入配置():
	配置文件o.seek(0)
	配置文件o.truncate(0)
	json.dump(配置,配置文件o,ensure_ascii=False,indent="\t",sort_keys=True)#格式化的json
	#json.dump(用户数据,配置文件o,ensure_ascii=False,separators=(',',':'))#压缩的json
	配置文件o.flush()

try:
	读取配置()
except json.decoder.JSONDecodeError as e:
	print('读取配置文件 "'+配置文件+'" 出错,在 第'+str(e.lineno)+'行 的 第'+str(e.colno)+'个 字符 (字符'+str(e.pos)+'):')
	截位=16
	截断=e.pos-(e.colno if e.colno<截位 else 截位)+1
	截断=e.doc[截断:截断+截位]
	print('行'+str(e.lineno)+': '+截断.replace('\n',' ').replace('\t',' ').replace('\r',''))
	print('检查附近的错误')
	if input('输入"y"以覆盖')=='y':
		写入配置()
	else:
		exit()
if __name__=='__main__':
	print(配置)