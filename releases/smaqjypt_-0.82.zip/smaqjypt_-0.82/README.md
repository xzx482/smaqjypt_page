# smaqjypt_
还没写完呢, 明年再写
#### 因为发现代码中含有隐私信息, 所以删除了之前的所有提交

## 快速开始
### 准备pyhton环境
若已安装了python3.7及以上版本, 可跳至下一步

#### 下载python
到python官网的下载页面[https://www.python.org/downloads/](https://www.python.org/downloads/)

点击最醒目的按钮即可下载最新版本的python
![](./img/download_py.png)
#### 安装python
运行下载的文件  
勾选 "Add Python 3.x to PATH"  
点击"Install Now"  
如图
![](./img/install_py.png)
等待安装完成
### 下载仓库
点击本页的"Code", 再点击"Download ZIP",如图
![](./img/download_repo.png)
### 解压
用任意的压缩软件解压下载的文件到空文件夹,并打开该文件夹
### 运行
打开"s.py"即可