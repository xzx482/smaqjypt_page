import os
from urllib import parse
from 终端控制 import 按任意键继续
from 访问 import 访问
from 全局常量 import 数据文件目录
import 解析html
import json
import time

def o_j(o)->str:
	return json.dumps(o,ensure_ascii=False,separators=(',',':'))

def 搜索(q):
	try:
		d=解析html.解析(访问("https://cn.bing.com/search?q="+parse.quote(q))[6])
		d_=d.查找(属性={'class':'b_focusTextLarge'})
		结果=''
		if len(d_)>0:
			结果=d_[0].内容[0]
		else:
			d_=d.查找(属性={'class':'rwrl rwrl_pri rwrl_padref'})
			if len(d_)>0:
				for i in d_[0].内容:
					if isinstance(i,str):
						结果+=i.replace('\n','')
					elif isinstance(i,解析html.Dom):
						结果+=i.内容[0]


		return 结果
	except:
		return ''

选项_数字={}
#输入_选项={}
#for i in range(26):
for i in range(9):
	si=str(i+1)
	ci65=chr(i+65)
	选项_数字[ci65]=si
	#选项_数字[chr(i+65+6+26)]=si
	#输入_选项[si]=ci65
	#输入_选项[ci65]=ci65
	#输入_选项[chr(i+65+6+26)]=ci65
	
#点击 "已完成观看，请点此确认" 即为签到
#step_类型=[签到,问卷]
def 制作(专题id,年级,退出=False):
	result=json.loads(访问("https://huodongapi.xueanquan.com/Topic/topic/main/api/v1/records/questions?specialId="+专题id+"&grade="+年级)[6])['result']

	step_问卷=False

	if result:
		step_问卷=True
		选错概率=input("该专题存在问卷,可设定随机选错,选错概率(0-10,默认1):")
		if 选错概率:
			try:
				选错概率=int(选错概率)
				if(选错概率<0):
					选错概率=1
			except:
				选错概率=1
		else:
			选错概率=1
	else:
		print('该专题没有问卷')

	性别_选择=False

	题目_已选=[]
	#{"module":1,"id":3,"type":"Radio","answer":"A"},
	题数=0
	for i in result:
		题数+=len(i["question"])
	print("共"+str(题数)+"题")
	for result_ in result:
		题目=result_["question"]
		for i in 题目:
			print(str(i["id"])+"."+i["title"])
			答案_={"module":result_["module"],"id":i["id"],"type":i["radioType"]}
			选项=[]
			for i2 in i["option"]:
				选项.append(i2["item"])
				print("    "+((选项_数字[i2["item"]]+'.')if i2["item"]in 选项_数字 else '  ')+i2["item"]+"."+i2["title"])
			if (not 性别_选择)and"性别"in i["title"]and(sum([i2 in i["option"][0]["title"]+i["option"][1]["title"] for i2 in"男女"])==2 and input("该选项为性别选项?(Y/n):")!='n'):
				性别_选择=True
				性别_={}
				for i2 in i["option"]:
					if len(性别_)>=2:
						break
					elif "男"in i2["title"]:
						性别_["1"]=i2["item"]
					elif "女"in i2["title"]:
						性别_["2"]=i2["item"]

				答案_["answer"]=[1,性别_]
			else:
				while 1:
					重选=False
					选择=input(":").upper().replace("1","A").replace("2","B").replace("3","C").replace("4","D").replace("5","E").replace("6","F").replace("7","G").replace("8","H").replace("9","I")
					if not 选择:
						continue
					elif 选择=='Q':
						print('bing搜索: ...',end='',flush=True)
						s=搜索(i["title"])
						print('\b'*3+' '*3+'\b'*3+s if s else '无结果')
						continue
					elif(i["radioType"]=="Radio"and len(选择)>1):
						print("该题为单选题,请重选")
						continue
					for i2 in 选择:
						if i2 not in 选项:
							print(i2+" 不在选项中,请重选")
							重选=True
							break
					
					if not 重选:
						break
					
				if 选错概率>0 and len(选项)>len(选择):
					answer_={}
					#(len(选项)-len(选择))
					
					#选择正确数=int(((len(选项)-len(选择))*10/选错概率-(len(选项)-len(选择)))/len(选择))
					选择正确数=int(len(选项)-len(选择)*(10/选错概率-1)/len(选择))
					for i2 in 选项:
						if i2 in 选择:
							answer_[i2]=选择正确数
						else:
							answer_[i2]=1
					
					if i["radioType"]=="CheckBox":
						答案_["answer"]=[2,[answer_,1,len(选项)]]
					else:
						答案_["answer"]=[2,[answer_,1]]
				else:
					答案_["answer"]=",".join([i2 for i2 in 选择])
				
			题目_已选.append(答案_)

	print(o_j(题目_已选))
	print()
	print()

	总模板={}
	step=1
	while 1:
		选择=input('该专题的第'+str(step)+'步为? '+(''if step_问卷 else'无(0) ')+'签到(1)'+(' 问卷(2)'if step_问卷 else '')+' :')
		if step>10 or 选择=='0':
			break
		elif 选择=='1':
			总模板[str(step)]='sign'
		elif step_问卷:
			if 选择=='2':
				总模板[str(step)]=题目_已选
				step_问卷=False
		else:
			continue
		step+=1

	print(o_j(总模板))
	print()
	print()

	文件名=数据文件目录+专题id+".json"
	if not((not os.path.isfile(文件名))or input('文件已存在,是否覆盖(N/y)')=='y'):
		文件名=文件名[:-5]+"."+str(round(time.time()*1000))+".json"
	with open(文件名,"w",encoding="utf-8")as f:
		#json.dump(总模板,f,ensure_ascii=False,indent="\t",sort_keys=True)#格式化的json
		json.dump(总模板,f,ensure_ascii=False,separators=(',',':'))#压缩的json

		print("文件已保存到 '"+文件名+"'")
	if 退出:
		按任意键继续(提示信息_3="退出")
	else:
		return 总模板
if __name__=='__main__':
	while 1:
		专题id=input("专题id:")
		try:
			专题id_=int(专题id)
			if 0<专题id_<1000:
				break
			raise
		except:
			print("输入有误")
			continue

	while 1:
		年级=input("年级(高一为10,高三为12,以此类推):")
		try:
			年级_=int(年级)
			if 0<年级_<13:
				break
			raise
		except:
			print("输入有误")
			continue
	
	制作(专题id,年级,True)