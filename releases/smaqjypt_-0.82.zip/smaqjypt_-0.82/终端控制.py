import os,time,sys
from wcwidth import wcwidth

def ww(s):
	a=0
	for i in s:
		if i =='\t':
			a+=8-a%8
		else:
			b=wcwidth(i)
			a+=1 if b==-1 else b
	return a




def 打印(值):
	#print(值,end='',flush=True)
	sys.stdout.write(str(值))
	sys.stdout.flush()
		 


def 设置光标位置(x,y):
	打印("\033["+str(y)+";"+str(x)+"H")

def 清除所有属性():
	打印("\033[0m")

def 清屏():
	打印("\033[2J")
	设置光标位置(0,0)

def 光标显示(显示=True):
	if(显示):
		打印("\033[?25h")
	else:
		打印("\033[?25l")

def 保存光标位置():
	打印("\033[s")

def 恢复光标位置():
	打印("\033[u")
'''
0:黑
1:红
2:绿
3:黄
4:蓝
5:紫
6:深绿
7:白
'''
def 设置颜色(文字颜色=None,背景颜色=None):
	if 文字颜色:
		打印("\033[3"+str(文字颜色)[0]+"m")
	if 背景颜色:
		打印("\033[4"+str(背景颜色)[0]+"m")

def 设置样式(文字颜色=None,背景颜色=None,高亮=None,下划线=None,闪烁=None,反显=None):
	设置颜色(文字颜色,背景颜色)
	if(高亮):
		打印("\033[1m")
	if(下划线):
		打印("\033[4m")
	if(闪烁):
		打印("\033[5m")
	if(反显):
		打印("\033[7m")

def 打印多样式文字(文字="",文字颜色=None,背景颜色=None,高亮=None,下划线=None,闪烁=None,反显=None):
	设置样式(文字颜色,背景颜色,高亮,下划线,闪烁,反显)
	打印(文字)
	清除所有属性()

def 移动光标(右,下):
	if(下<0):
		打印("\033["+str(-下)+"A")
	if(下>0):
		打印("\033["+str(下)+"B")
	if(右<0):
		打印("\033["+str(-右)+"D")
	if(右>0):
		打印("\033["+str(右)+"C")

def 位置打印(位置,文字="",文字颜色=None,背景颜色=None,高亮=None,下划线=None,闪烁=None,反显=None):
	保存光标位置()
	设置光标位置(位置[0],位置[1])
	打印多样式文字(文字,文字颜色,背景颜色,高亮,下划线,闪烁,反显)
	恢复光标位置()



def 加载(f,间隔=.25,超时=40,a_='/-\\|'):
		a_='/-\\|'
		a__=0
		t=time.time()
		while 1:
			a=f()
			if a:
				print('\b \b',end='')
				return a
			else:
				if time.time()-t>超时:
					return False
				print('\b'+a_[a__],end='',flush=True)
				a__+=1
				if a__>=len(a_):
					a__=0
			time.sleep(间隔)



class 输出_底():
	def __init__(s,标准输出=sys.stdout):
		s.标准输出=标准输出
		s.输出锁=False
		s.底内容=''
		s.底_上次长度=0

	def 输出(s,内容,末尾='\n'):
		try:
			while s.输出锁:
				time.sleep(0.01)
			s.输出锁=True
			s.标准输出.write('\r'+' '*s.底_上次长度+'\r'+str(内容)+末尾+s.底内容)
			s.底_上次长度=ww(s.底内容)
			s.标准输出.flush()
		finally:
			s.输出锁=False
			


	def 底_输出(s,内容):
		s.底内容=str(内容)
		s.输出('','')

	def 清除(s):
		s.底内容=''
		s.输出('','')



if os.name=='nt':
	os.system("")#win玄学, 这样\033[xxxm 才能用
	#如果玄学还不行, 还有大招
	from wincmd import 获取光标位置,设置光标位置,设置颜色,打印彩色文字,打印多样式文字,保存光标位置,恢复光标位置


def 清屏():
	'''
清空屏幕,部分命令行或终端不支持

'''
	if(os.name == "nt"):
		os.system('cls')
	elif(os.name == "posix"):
		os.system('clear')

def 获取键盘输入_linux():
	'''
在类linux使用,调用后可得到一个键盘输入而不显示在屏幕

返回值:
	输入键盘的字符

'''
	fd=sys.stdin.fileno()
	old_settings=termios.tcgetattr(fd)
	try:
		tty.setraw(sys.stdin.fileno())
		键盘输入=sys.stdin.read(1)
	except:''
	termios.tcsetattr(fd,termios.TCSADRAIN,old_settings)
	return 键盘输入

def 密码输入_linux(提示文字="密码:"):
	'''
在类linux使用,调用后可输入显示为星号"*"的密码,左右键可移动光标(部分终端不支持),输入完成后按回车,返回值为输入的密码

参数:
	提示文字
		调用函数后给用户输入密码的提示文字,显示在左侧

返回值:
	输入的密码

'''
	文本=""
	光标位置=0
	print(提示文字,end="",flush=True)
	while 1:
		键盘输入=获取键盘输入_linux()
		if(键盘输入==""):
			''
		elif(键盘输入=='\r'):
			break
		elif(键盘输入=='\x03'):#Ctrl+C
			raise KeyboardInterrupt
		elif(键盘输入=='\b' or 键盘输入=='\x7f'):#退格
			if(光标位置):
				文本=文本[0:光标位置-1]+文本[光标位置:]
				光标位置-=1
				#print("*"*(len(文本)-光标位置)+"\b "+"\b"*(len(文本)-光标位置+1),end="",flush=True)
		elif(键盘输入=='\x1b'):
			键盘输入=获取键盘输入_linux()
			if(键盘输入=='\x5b'):#方向键
				键盘输入=获取键盘输入_linux()
				if(键盘输入=='\x44'):#左
					if(光标位置):
						#print("\b",end="",flush=True)
						光标位置-=1
				if(键盘输入=='\x43'):#右
					if(光标位置<len(文本)):
						#print("*",end="",flush=True)
						光标位置+=1
		else:
			#print("//"+str(键盘输入.hex())+"//")
			try:文本=文本[0:光标位置]+键盘输入+文本[光标位置:]
			except:
				''#print("\r提示:无效的文本   ")
			else:
				光标位置+=1
				#print("*"*(len(文本)-光标位置+1)+"\b"*(len(文本)-光标位置),end="",flush=True)
		#print("\b"*(光标位置-1)+"*"*len(文本)+" "+"\b"*(len(文本)-光标位置+1),end="",flush=True)#
		print("\r"+提示文字+"*"*len(文本)+" "+"\b"*(len(文本)-光标位置+1),end="",flush=True)#星号输入
		#print(hex(ord(str(键盘输入))))
		#print("\r"+提示文字+文本+" "+"\b"*(len(文本)-光标位置+1),end="",flush=True)#明文输入
		#'''
	print()
	return 文本


def 密码输入_win(提示文字="密码:"):
	'''
在win使用,调用后可输入显示为星号"*"的密码,左右键可移动光标(部分命令行或终端不支持),输入完成后按回车,返回值为输入的密码

参数:
	提示文字
		调用函数后给用户输入密码的提示文字,显示在左侧

返回值:
	输入的密码

'''
	文本=""
	光标位置=0
	print(提示文字,end="",flush=True)
	#if(1):
	while 1:
		try:
			键盘输入=''
			键盘输入=msvcrt.getch()#.decode(encoding="utf-8").decode("hex")#.decode(encoding="utf-8")
		except:print('1')
		#print(" "+str(键盘输入.hex()),end="",flush=True)
		#'''
			#return input("12")
		if(键盘输入==""):
			''
		elif(键盘输入==b'\r'):
			break
		elif(键盘输入==b'\x03'):#Ctrl+C
			raise KeyboardInterrupt
		elif(键盘输入==b'\x08'):#退格
			if(光标位置):
				文本=文本[0:光标位置-1]+文本[光标位置:]
				光标位置-=1
				#print("*"*(len(文本)-光标位置)+"\b "+"\b"*(len(文本)-光标位置+1),end="",flush=True)
		elif(键盘输入==b'\xe0'):#方向键
			键盘输入=msvcrt.getch()
			if(键盘输入==b'\x4b'):#左
				if(光标位置):
					#print("\b",end="",flush=True)
					光标位置-=1
			if(键盘输入==b'\x4d'):#右
				if(光标位置<len(文本)):
					#print("*",end="",flush=True)
					光标位置+=1
		else:
			#print("//"+str(键盘输入.hex())+"//")
			try:文本=文本[0:光标位置]+键盘输入.decode(encoding="utf-8")+文本[光标位置:]
			except:
				''#print("\r提示:无效的文本   ")
			else:
				光标位置+=1
				#print("*"*(len(文本)-光标位置+1)+"\b"*(len(文本)-光标位置),end="",flush=True)
		#print("\b"*(光标位置-1)+"*"*len(文本)+" "+"\b"*(len(文本)-光标位置+1),end="",flush=True)#
		print("\r"+提示文字+"*"*len(文本)+" "+"\b"*(len(文本)-光标位置+1),end="",flush=True)#星号输入
		#print("\r"+提示文字+文本+" "+"\b"*(len(文本)-光标位置+1),end="",flush=True)#明文输入
		#'''
	print()
	return 文本

def 密码输入_明文(提示文字="密码:"):
	'''
在不支持使用星号"*"来隐藏密码时使用

参数:
	提示文字
		调用函数后给用户输入密码的提示文字,显示在左侧

返回值:
	输入的密码

'''
	print("注意:密码会显示")
	return input(提示文字)


try:
	import msvcrt
	密码输入=密码输入_win
	

	def 按任意键继续(提示信息="",提示信息_0="按",提示信息_1="任意",提示信息_2="键",提示信息_3="继续"):
		print(提示信息+提示信息_0+提示信息_1+提示信息_2+提示信息_3,end="",flush=True)
		if(msvcrt.getch()==b'\x03'):
			raise KeyboardInterrupt
		print()
except:
	try:
		import termios
		import tty
		密码输入=密码输入_linux

		def 按任意键继续(提示信息="",提示信息_0="按",提示信息_1="任意",提示信息_2="键",提示信息_3="继续"):
			print(提示信息+提示信息_0+提示信息_1+提示信息_2+提示信息_3,end="",flush=True)
			if(获取键盘输入_linux()=='\x03'):
				raise KeyboardInterrupt
			print()
	except:
		密码输入=密码输入_明文
		def 按任意键继续(提示信息="",提示信息_0="按",提示信息_1="回车",提示信息_2="键",提示信息_3="继续"):
			print(提示信息+提示信息_0+提示信息_1+提示信息_2+提示信息_3,end="",flush=True)
			input()

