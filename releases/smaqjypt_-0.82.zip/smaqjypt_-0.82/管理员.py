'''
从html文件流中对管理员的信息获取
'''
from 访问 import 访问
import 用户
import 解析html

def 去空(s):
	return s.replace('\r\n','').replace(' ','')

url头="https://sanming.xueanquan.com"

def 获取学生列表(用户_):
	html=解析html.解析(访问(url头+"/eduadmin/ClassManagement/ClassManagement",{"Cookie":用户_.cookie},"POST","numPerPage=2500")[6])
	表格=解析html.解析表格(html)
	用户_={}
	for i in 表格:
		用户_[
			去空(i[2][0])
		]=\
			[去空(i[1][0]),True if'已'in i[3][1].内容[0]else False,url头+i[4][1].属性['href']]
	return 用户_




def 获取开展情况url(用户_):
	html=解析html.解析(访问(url头+'/EduAdmin/Home/Index',cookie=用户_.cookie)[6])
	teacher_li2_ul=html.查找_多条件([{'属性':{'id':'teacher_li2'}},{'标签':'ul'}])[0]
	活动开展情况=teacher_li2_ul.查找_多条件([{'文本':'活动开展情况','父级':1},{'标签':'ul','父级':0}])[0]
	专题课开展情况=teacher_li2_ul.查找_多条件([{'文本':'专题课开展情况','父级':1},{'标签':'ul','父级':0}])[0]
	学生学习情况url=teacher_li2_ul.查找_多条件([{'文本':'学生学习情况'},{'标签':'a'}])[0].属性['href']
	学生学习情况url=url头+学生学习情况url
	#print(活动开展情况)
	开展情况_={}
	for 开展情况 in[活动开展情况,专题课开展情况]:
		for i in 开展情况:
			if isinstance(i,解析html.Dom)and i.标签=='li':
				i=i.查找(标签='a')[0]
				if i.属性['href'][:10]!='javascript':
					开展情况_[
						i.属性['title']
						if 'title' in i.属性
						else
						i.内容[0].split(' ')[-1]
					]=\
						url头+解析html.解实体(i.属性['href'])
	html=解析html.解析(访问(学生学习情况url,cookie=用户_.cookie)[6])
	tr_s=html.查找_多条件([{'标签':'table'},{'标签':'tr','所有':True}])[1:]
	学生学习情况={}
	for tr in tr_s:
		学生学习情况[
			去空(tr.查找_多条件([{'标签':'td','所有':True}])[-6].内容[0])
		]=\
			url头+tr.查找_多条件([{'标签':'a','所有':True},{'文本':'查看','所有':True}])[0].属性['href']


	return [开展情况_,学生学习情况]

def 获取完成情况(用户_,url):
	w=解析html.解析(访问(url,数据='numPerPage=1000',cookie=用户_.cookie)[6])
	table=w.查找(标签='table',所有=True)[-1]
	完成情况_={}
	pagination=w.查找(属性={'class':"pagination"})[0]
	if pagination.属性['totalcount'].isdigit() and int(pagination.属性['totalcount'])>0:
		表格=解析html.解析表格(table)
		for i in 表格:
				#i[1][1][1][0].replace('\r\n','').replace(' ',''),
			完成情况_[
				i[1][0].replace('\r\n','').replace(' ','')
			]=\
				True if'已'in (i[2][1].内容[0] if len(i[2])>1 else i[2][0])else False
	return 完成情况_

