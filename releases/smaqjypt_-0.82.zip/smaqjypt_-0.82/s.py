import sys,shutil,_thread,traceback,time,json,copy,os
from urllib import request,parse

import 用户,管理员
from 访问 import 访问,解码
from 全局常量 import 数据文件目录,错误信息文件目录,用户表文件目录,用户数据文件,专题id文件,配置文件,更新url,修改密码,弱密码列表,完成延迟,教程_阶段,配置,写入配置,初次使用,修改密码匹配,配置文件o
from 终端控制 import 密码输入,输出_底,清屏,按任意键继续,位置打印,设置光标位置

#'''
__类型__=[
	0, #0:源码, 1:EXE, 2:ELF
	0  #0:目录, 1:单文件
]

'''
from __类型__ import __类型__
#'''


__版本__=0.82
__doc__="版本:"+str(__版本__)

输出=用户.输出







用户数据文件o=open(用户数据文件,"a+")



用户数据={}
用户数据_写入=[time.time(),False]

def 读用户数据():
	global 用户数据
	用户数据文件o.seek(0)
	用户数据_=json.load(用户数据文件o)
	用户数据_.update(用户数据)
	用户数据=用户数据_

def 写用户数据_(读取=True):
	if 读取:
		读用户数据()
	用户数据文件o.seek(0)
	用户数据文件o.truncate(0)
	json.dump(用户数据,用户数据文件o,ensure_ascii=False,indent="\t",sort_keys=True)#格式化的json
	#json.dump(用户数据,用户数据文件o,ensure_ascii=False,separators=(',',':'))#压缩的json
	用户数据文件o.flush()

def 写用户数据():
	global 用户数据_写入
	if 用户数据_写入[1]:
		return
	用户数据_写入[1]=True
	try:
		t=time.time()
		if t>=用户数据_写入[0]+20:
			用户数据_写入[0]=t
		else:
			time.sleep(用户数据_写入[0]-t+20)
		写用户数据_()
	except:
		用户数据_写入[1]=False
		raise
	用户数据_写入[1]=False
		
def 写用户数据__():
	try:
		写用户数据_()
		return True
	except:
		print('注意:用户数据无法保存,以下为用户数据,请自行保存到 "'+用户数据文件+'" ')
		print('----用户数据_开始----')
		print(json.dumps(用户数据,ensure_ascii=False,separators=(',',':')))
		print('----用户数据_结束----')
		print('注意:用户数据无法保存,以上为用户数据,请自行保存到 "'+用户数据文件+'" ')
		return False

def 重写用户数据():
	global 用户数据文件o
	备份文件名=用户数据文件+'.'+获取格式化时间()+'.bak'
	用户数据文件o.close()
	os.rename(用户数据文件,备份文件名)
	print('原用户数据已备份到"'+备份文件名+'"')
	用户数据文件o=open(用户数据文件,"a+")
	#用户数据文件o.write('{}')
	写用户数据_(False)
try:
	读用户数据()
except json.decoder.JSONDecodeError:
	写用户数据_(False)

class 返回(KeyboardInterrupt):
	pass

class 交互登录_错误(用户.错误):
	pass

class 强制退出(SystemExit):
	pass

def 获取首字母(用户名):
	拼音=用户名.strip('0123456789')
	首字母=''
	a=1
	while(a<=len(拼音)):
		if 拼音[a-1:a+1]in['zh','ch','sh']:
			首字母+=拼音[a-1:a]
			a+=2
			
		elif 拼音[a-1:a]in'bpmfdtlkhjqwyrxzcs':
			首字母+=拼音[a-1:a]
			a+=1
		elif 拼音[a-1:a]in'gn'and a<len(拼音)and 拼音[a:a+1]not in'bpmfdtlkhjqwyrxzcsgn':
			首字母+=拼音[a-1:a]
			a+=1
		else:
			a+=1
	return 首字母

def 获取格式化时间(时间=None):
	if not 时间:
		时间=time.time()
	return time.strftime("%Y%m%d-%H%M%S",time.localtime(时间))+"."+str(时间).split(".")[1]

def 登录(用户名:str="",密码:str="",保存用户信息=True,假登录=None,输出=输出):
	'''
"用户.登录"的交互式登录
可传入参数,也可直接调用,直接调用有交互式的用户名和密码输入,传入参数后不会有交互式提示
注意,安全教育平台增加了次数限制,因此 尝试简单密码 功能 已取消
*若没有传入或输入密码,则会检查是否已保存在"用户数据文件"中,<删除线>再尝试简单的密码:"123456","123456首字母","首字母123456" 在下面的"弱密码列表"中</删除线>

参数:
	用户名:
		要登录的用户名
	
	密码:
		用户名对应的密码
	
	保存用户信息:
		登录成功后是否保存用户信息到 用户数据文件 中
	
	假登录:
		使用现在网页的登录接口以表示正常地登录,但实际上返回的数据仍需再发送到以前的接口以获得用户信息.使用它的目的是防止被风控发现异常

返回值:
	用户

'''
	if 假登录 is None:
		假登录=配置['假登录']

	自动=False
	用户信息=用户.用户()
	用户信息.输出=输出
	if(用户名==""and 密码!=""):
		raise 交互登录_错误("密码不为空但用户名为空")
	

	if(用户名!=""):
		自动=True
	while(not 用户信息.cookie):
		新登录=True
		if(not 自动):
			#print('-'*18)
			用户名=input("用户名:")
		
		if(not 用户名 or "`"in 用户名):
			raise 返回
		
		if(not 自动):
			密码=密码输入()
			time.sleep(0.08)
		if(not 密码 and not(len(用户名)==32 and 用户名.isupper())):
			
			if 用户名 in 用户数据:
				输出("使用已保存的用户信息")
				新登录=False
				用户信息.cookie=用户数据[用户名][0]
				用户信息.用户信息=用户数据[用户名][1]
			else:
				'''
				#弱密码登录
				首字母=获取首字母(用户名)
				#print("首字母:"+首字母)
				弱密码列表=[
					"123456",
					"123456aA",
					"123456"+首字母+首字母.upper(),
					首字母+首字母.upper()+"123456",
					"123456"+首字母,
					首字母+"123456",
				]
				'''


				#弱密码列表=["123456aA","123456"]
				a=0
				for 弱密码 in [修改密码]+弱密码列表:
					a+=1
					输出("尝试"+str(a)+"/"+str(len(弱密码列表)+1)+"个")
					try:
						用户信息.登录(用户名,弱密码,假登录_=假登录)
						break
					except 用户.登录_错误 as 信息:
						if 用户信息.状态!=-1:
							输出("错误 "+str(用户信息.状态)+" 信息:"+str(信息))
				if 用户信息.cookie:
					输出("登录成功")
				else:
					输出("登录失败")

		else:
			try:
				if not 密码 and len(用户名)==32 and 用户名.isupper():
					用户信息.登录(UserID=用户名,假登录_=假登录)
				else:
					用户信息.登录(用户名,密码,假登录_=假登录)
				输出("登录成功")
			except 用户.错误 as 信息:
				if(用户信息.状态==-1):
						输出("用户名或密码错误")
				else:
					输出("错误 "+str(用户信息.状态)+" 信息:"+str(信息))
		if 自动:
			break
		
	if 新登录 and 用户信息.cookie and 保存用户信息:
		用户信息列表=用户信息.转列表()
		用户数据[用户信息列表[1]['UserName']]=用户信息列表
		写用户数据()

		

			
	return 用户信息

def 自动完成(用户_:用户.用户,延迟=配置['延迟'],输出=输出):
	'''
快速完成用户在 三明安全教育平台 中的所有未完成作业

参数:
	用户:
		已登录的"用户"对象
	延迟:
		1为模拟正常人的速度,0为不延迟,2为比正常人慢一倍,以此类推,可为小数,对于完成作业有效

返回值:
	错误信息列表

'''
	作业=用户_.查询作业()
	用户_.延迟=延迟
	time.sleep(完成延迟.查询作业*延迟)
	错误=[]
	完成作业=False
	for 作业id in 作业:
		try:
			if not 作业[作业id][3]:
				time.sleep(完成延迟.自动完成*延迟)
				完成作业=True
				用户_.完成作业(作业id,作业[作业id])
		except 用户.完成_作业_错误 as 错误信息:
			错误信息='完成"'+作业[作业id][0]+'"错误:'+str(错误信息)
			错误.append(错误信息)
			输出('错误:'+错误信息)
	if not 完成作业:
		输出("没有未完成的作业")
	return 错误




class 批量完成_错误(用户.错误):
	pass


class 批量完成:
	def __init__(s)->None:
		s.状态=0 # 0:未开始, 1:已开始但未结束, 2:已结束
		s.已尝试数=0
		s.总数=0
		s.未完成信息={}
		s.用户_={}
		s.最大线程数=2
		s.自动保存=True
		s.延迟=配置['延迟'] #1为模拟正常人的速度,0为不延迟,2为比正常人慢一倍,以此类推,可为小数
		s.输出_底=输出_底()
		s.底出=s.输出_底.底_输出
		s.输出=s.输出_底.输出

	def 添加用户(s,用户_:dict)->None:
		if s.状态:
			raise 批量完成_错误("已开始后不能添加")
		s.用户_.update(用户_)
		s.总数=len(s.用户_)

	def 保存(s,文件名=None)->None:
		a=''
		for i in s.用户_:
			a+=i+'\n'
		
		if(文件名):
			文件名=str(文件名)
		else:
			时间=time.time()
			文件名=time.strftime("%Y%m%d-%H%M%S",time.localtime(时间))+"."+str(时间).split(".")[1]
		with open(用户表文件目录+文件名+".txt","w") as f:
			f.write(a)

	def 开始(s,保存=None):
		_thread.start_new_thread(s.开始_,())
		if 保存 is None:
			保存=s.自动保存
		if 保存:
			s.保存()
	def 开始_(s):
		s.状态=1
		s.总数=len(s.用户_)
		s.用户_=list(s.用户_.items())
		for i in range(len(s.用户_)):
			while(i+1-s.已尝试数>s.最大线程数):
				time.sleep(0.1)
			_thread.start_new_thread(s.完成单用户,(i,))
			time.sleep(完成延迟.批量完成*s.延迟)
			time.sleep(0.2)

		while(s.已尝试数<s.总数):
			time.sleep(0.2)
		s.状态=2
	def 显示_(s):
		if(s.已尝试数):
			s.底出("第"+str(s.已尝试数)+"个,共"+str(s.总数)+"个 "+str(s.已尝试数*100/s.总数)[:5]+"%"+"\t"+str(s.用户_[s.已尝试数-1][0]))
		else:
			s.底出("第0个,共"+str(s.总数)+"个 0%"+"\t准备中")
	def 显示(s,t=.1):
		a=-1
		while s.状态!=2:
			if(a<s.已尝试数):
				a=s.已尝试数
				s.显示_()
			else:
				time.sleep(t)
		s.输出_底.清除()
		print()

	def 完成单用户(s,i:int)->None:
		用户_=登录(*s.用户_[i],输出=s.输出)
		用户_.输出=s.输出
		if(用户_.cookie):
			未完成信息=自动完成(用户_,s.延迟,s.输出)
			if(未完成信息):
				s.未完成信息[用户_.用户名]=未完成信息
		else:
			s.未完成信息[用户_.用户名]=[str(用户_.状态)]
		s.已尝试数+=1

	def 打印未完成(s):
		'return [未完成_密码错误,未完成_其他错误]'
		未完成_密码错误=[]
		未完成_其他错误={}
		for i in s.未完成信息:
			if(s.未完成信息[i][0] in ["-1","-3"]):
				未完成_密码错误.append(i)
			else:
				未完成_其他错误[i]=s.未完成信息[i]

		if 未完成_其他错误:
			s.输出("以下用户发生错误:")
			for i in 未完成_其他错误:
				s.输出("\t"+i+"\n\t\t"+"\n\t\t".join(未完成_其他错误[i]))

		if 未完成_密码错误:
			s.输出("以下用户密码错误:\n\t"+"\n\t".join(未完成_密码错误))
		
		if ((not 未完成_密码错误)and(not 未完成_其他错误)):
			print("已全部完成")
		return [未完成_密码错误,未完成_其他错误]


def 异步_获取开展情况url(用户_):
	while 1:
		try:
			用户_._['开展情况url']=管理员.获取开展情况url(用户_)
			break
		except:
			pass
	

def 完成管理员名下学生作业(用户_,路径):
	'''
完成管理员名下学生作业

参数:
	用户_:
		使用管理员的"用户名"和"密码"在"登录"得到的"用户信息"

'''
	if(用户_.用户信息["UserType"]!=1):
		print("该用户非管理员用户")
		return 0
	
	用户信息_表=管理员.获取学生列表(用户_)
	要完成表={}
	#input(用户信息_表)
	while 1:
		清屏()
		路径=路径[:2]
		print('>'.join(路径))
		print('要完成哪些\n'
		'1.全部(默认)\n2.未完成特定作业')
		输入=input(':')
		if'`'in 输入 or 输入=='':
			return
		elif  输入=='1':
			路径=路径[:2]
			路径.append('全部')
			清屏()
			print('>'.join(路径))
			要完成表={i:""for i in 用户信息_表}
			break
		elif 输入=='2':
			用户_._['开展情况url']=None
			_thread.start_new_thread(异步_获取开展情况url,(用户_,))
			while 1:
				清屏()
				路径=路径[:2]
				路径.append('未完成特定作业')
				print('>'.join(路径))
				print('1.专题活动\n2.技能训练')
				输入=input(':')
				if 输入 in['','`']:
					break
				elif 输入 in['1','2']:
					#清屏()
					路径=路径[:3]
				else:
					continue
				#开展情况url=加载(lambda :用户_._['开展情况url'])
				while 1:
					if 用户_._['开展情况url']:
						开展情况url=用户_._['开展情况url']
						break

				if 输入=='1':
					开展情况url_=开展情况url[0]
					路径.append('专题活动')
				if 输入=='2':
					开展情况url_=开展情况url[1]
					路径.append('技能训练')
				while 1:
					清屏()
					路径=路径[:4]
					print('>'.join(路径))
					a=0
					a_={}
					for i in 开展情况url_:
						a+=1
						a_s=str(a)
						a_[a_s]=i
						print(a_s+'.'+i)
					输入=input(':')
					if 输入 in['`','']:
						break
					if 输入 in a_:
						完成情况=管理员.获取完成情况(用户_,开展情况url_[a_[输入]])
						if 完成情况:
							for i in 用户信息_表:
								if not 完成情况[ 用户信息_表[i][0] ]:
									要完成表[i]=''
							if not 要完成表:
								print('没有人未完成 "'+a_[输入]+'"')
								time.sleep(.4)
								continue
							清屏()
							路径=路径[:4]
							路径.append(a_[输入])
							print('>'.join(路径))
							break
						else:
							print('专题"'+a_[输入]+'"未开展')
							time.sleep(.4)
							continue
				if 要完成表:
					break
		if 要完成表:
			break


	批1=批量完成()

	时间=time.time()
	#未完成表1=使用用户名密码表完成(要完成表,保存表_文件名=用户.用户信息["UserName"]+"_"+time.strftime("%Y%m%d-%H%M%S",time.localtime(时间))+"."+str(时间).split(".")[1],打印未完成=True)

	#未完成表1_密码错误=未完成表1[2]
	批1.添加用户(要完成表)
	批1.开始()

	批1.显示()

	未完成_密码错误=批1.打印未完成()[0]
	
	if(未完成_密码错误 and input('密码错误可尝试重置密码,输入"y"尝试重置,否则跳过')=="y"):
	
	
		重置密码用户名列表=未完成_密码错误
		
		for index in 重置密码用户名列表:
			try:
				重置密码地址=用户信息_表[index][2]
			except:
				print("注意:\""+str(index)+"\"不在该管理员名下,不能重置")
			else:
				a=json.loads(访问(重置密码地址,{"Cookie":用户_.cookie})[6])
				if(a["statusCode"]=="200"):
					print("成功,重置密码\""+index+"\",信息:"+a["message"])
				else:
					print("失败,重置密码\""+index+"\",状态"+str(a["statusCode"])+",信息:"+a["message"])
				
		批2=批量完成()
		批2.添加用户({i:""for i in 重置密码用户名列表})
		批2.开始(False)

		批2.显示()
		
		未完成_密码错误=批2.打印未完成()[0]

		if(未完成_密码错误):
			print("注意:重置密码后仍有密码错误")
	



def 显示作业列表(用户_:用户.用户,路径):
	'''
列出用户在 三明安全教育平台 中的所有作业,可选择完成

参数:
	用户_:
		已登录的"用户"对象

'''
	time.sleep(.4)
	while 1:
		清屏()
		print('>'.join(路径))
		print("用户名:"+用户_.用户信息["UserName"]+"\n")
		print("作业id\t类型    \t布置时间\t完成时间\t\t标题\n")
		作业=用户_.查询作业()
		for 作业id in 作业:
			#作业id
			作业_输出=作业id+"\t"
			#类型
			if(作业[作业id][1]==1):
				作业_输出+="安全学习"
			elif(作业[作业id][1]==2):
				作业_输出+="未知    "
			else:
				作业_输出+="专题活动"
			#布置时间
			作业_输出+="\t"+作业[作业id][2]+"\t"
			#完成时间
			if(作业[作业id][3]):
				作业_输出+=作业[作业id][3]
			else:
				作业_输出+="未完成                "
			#标题
			已结束=""
			if(作业[作业id][4][4]==0):
				已结束="(已结束)"
			作业_输出+="\t"+已结束+作业[作业id][0]
			print(作业_输出)
		while 1:
			输入=input("输入作业id以尝试完成:")
			if"`"in 输入 or 输入=='':
				raise 返回
			elif 输入 in 作业:
				提示=True
				if(作业[输入][3]):
					print("注意:该作业已完成,再次完成?",end='')
				elif(作业[输入][4][4]==0):
					print("注意:该作业已结束,尝试完成?",end='')
				else:
					提示=False
				if(提示 and input("(Y/n):")=="n"):
					continue
				作业id=输入
				try:
					用户_.完成作业(作业id,作业[作业id])
					time.sleep(.4)
					break
				except 用户.完成_作业_错误 as 错误信息:
					输出('错误:完成"'+作业[作业id][0]+'"错误:'+repr(错误信息))
				
			elif'-2'==输入:#刷新
				break
			else:
				print("输入错误,请重新输入")
		


找到更新=[0,False]

def 检查更新_(url,更新url):
	global 找到更新
	if 找到更新[1]:
		return
	try:
	#if 1:
		版本更新_=request.urlopen(request.Request(url,headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36 Edg/88.0.705.63"}))
		if str(版本更新_.getcode())[0]=="2" and not 找到更新[1]:
			找到更新[1]=json.loads(解码(版本更新_.read()))
			找到更新[1].update({'更新url':更新url})
		版本更新_.close()
	except:pass
	if isinstance(找到更新,list):
		找到更新[0]+=1
	return

检查更新_状态=0
主界面=True
检查更新_信息=[lambda:(位置打印((20,0),'检查更新...')),lambda:(位置打印((20,0),'有更新,输入"g"并回车查看',2)),lambda:(位置打印((20,0),'没有更新   ')),lambda:(位置打印((20,0),'检查更新失败   ',1))]
def 检查更新():
	global 找到更新,检查更新_状态
	for i in 更新url:
		_thread.start_new_thread(检查更新_,(i+"%E6%9C%80%E6%96%B0%E7%89%88%E6%9C%AC.json",i))
		#检查更新_(i+"%E6%9C%80%E6%96%B0%E7%89%88%E6%9C%AC.json",i)
		if 找到更新[1]:
			break
	if 主界面:
		检查更新_信息[检查更新_状态]()
	_thread.start_new_thread(检查更新_0,())

def 检查更新_0():
	global 找到更新,检查更新_状态
	try:
		a=16_0
		for i in range(a):
			if 找到更新[1] or 找到更新[0]>=len(更新url):
				break
			time.sleep(.1)
		找到更新=找到更新[1]
		if 找到更新:
			if(
				找到更新["版本"]>__版本__ and\
				len( 找到更新['url'] )>__类型__[0]and\
				len( 找到更新['url'] [__类型__[0]] )>__类型__[1]and\
				找到更新['url'] [__类型__[0]] [__类型__[1]]
			):#有更新
				检查更新_状态=1
			else:
				检查更新_状态=2
		else:
			检查更新_状态=3
	except:
		检查更新_状态=3
	
	if 主界面:
		检查更新_信息[检查更新_状态]()

__类型__0=['源码','EXE','ELF']
__类型__1=['目录','单文件']

def 检查更新_2():
	print('这是'+(__类型__0[__类型__[0]]if __类型__[0]<len(__类型__0)else'未知')+'的'+(__类型__1[__类型__[1]]if __类型__[1]<len(__类型__1)else'未知')+'版本')
	print('检查更新...',end='',flush=True)
	global 找到更新,检查更新_状态
	找到更新=[0,False]
	for i in 更新url:
		_thread.start_new_thread(检查更新_,(i+"%E6%9C%80%E6%96%B0%E7%89%88%E6%9C%AC.json",i))
		#检查更新_(i+"%E6%9C%80%E6%96%B0%E7%89%88%E6%9C%AC.json",i)
		if 找到更新[1]:
			break
	a_='-\\||/'
	a=16
	cl=5
	print(' '*cl,end='',flush=True)
	for i in range(a):
		afs=str((a-i)*5//10)
		afs=afs+' '*(1-len(afs))
		print('\b'*cl+' '*cl+'\b'*cl+a_[i%len(a_)]+'   '+afs,end='',flush=True)
		if 找到更新[1] or 找到更新[0]>=len(更新url):
			print('\b'*cl+' '*cl)
			break
		time.sleep(.5)
	找到更新=找到更新[1]
	if 找到更新:
		if(
			找到更新["版本"]>__版本__ and\
			len( 找到更新['url'] )>__类型__[0]and\
			len( 找到更新['url'] [__类型__[0]] )>__类型__[1]and\
			找到更新['url'] [__类型__[0]] [__类型__[1]]
		):
			检查更新_状态=1
			print('有更新\n')
			'更新内容'in 找到更新 and print(找到更新['更新内容'])
			if(input('\n输入"y"并回车可更新:')=='y'):
				print('下载...')
				找到文件=False
				for i in 找到更新['url'] [__类型__[0]] [__类型__[1]]:
					try:
						新文件_响应=request.urlopen(request.Request(parse.urljoin(找到更新['更新url'],i),headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36 Edg/88.0.705.63"}))
						if(新文件_响应.getcode()>=300):
							raise
						找到文件=True
						break
					except:
						continue
						
						#break
				if 找到文件:
					文件名=sys.argv[0]
					目录名=os.path.dirname(文件名)
					响应头=新文件_响应.info()
					#判断文件后缀是否相同
					下载文件名=\
						响应头['Content-Disposition'].split('filename=')[1]\
						if 'Content-Disposition' in 响应头 and 'filename=' in 响应头['Content-Disposition']\
						else os.path.basename(parse.urlsplit(新文件_响应.geturl()).path)
					k=[下载文件名.split('.')[-1].lower(),文件名.split('.')[-1].lower()]
					if __类型__[1]==0:#为目录
						k[1]='zip'
					elif k[0]!=k[1]:#为文件且后缀不同
						if input("警告:原文件和新文件的扩展名("+k[0]+'和'+k[1]+")不同,若继续可能导致无法使用.\n这可能是意外导致的,如非必要,建议放弃本次更新.\n是否继续更新(N/y)")!='y':
							raise
						
					#os.chdir(目录名)
					临时文件名=目录名+'/'"更新.tmp"
					#方式=0
					while 1:
						try:
							f=open(临时文件名,"wb")
							break
							#f=open(新文件名,"wb")
							#方式=1
						except:
							'''
							try:
								f=open(临时文件名,"wb")
								方式=2
							except:'''
							按任意键继续('无法写入文件 "'+临时文件名+'" ,请检查权限.',提示信息_3='重试')
					已下载=[0,time.time()]
					try:
						大小=int(响应头['content-length'])//1024 # 单位 KB
						大小_s=str(大小)
					except:
						大小=0
					while 1:
						d=新文件_响应.read(1024)
						if not d:
							break
						f.write(d)
						已下载[0]+=1
						t=time.time()
						if t-已下载[1]>0.2:
							已下载[1]=t
							输出='已下载'+str(已下载[0])+'KB'
							if 大小:
								输出=输出+'  共'+大小_s+'KB  '+str(round(已下载[0]/大小*100))+'%'
							print('\r'+输出,end='',flush=True)
					print('\r已下载'+大小_s+'KB  共'+大小_s+'KB  100%')

					f.close()
					if __类型__[1]==0:#目录
						import zipfile
						print('更新文件...')
						#os.rename(临时文件名,新文件名)
						if zipfile.is_zipfile(临时文件名):
							zf=zipfile.ZipFile(临时文件名,'r')
							临时文件夹名=目录名+'/''tmp'
							os.path.isdir(临时文件夹名)and shutil.rmtree(临时文件夹名)
							os.path.isfile(临时文件夹名)and os.remove(临时文件夹名)
							os.mkdir(临时文件夹名)
							zf.extractall(临时文件夹名)#解压文件
							临时文件夹名_=临时文件夹名
							#排除多余的根文件夹
							while 1:
								l_=os.listdir(临时文件夹名_)
								if len(l_)<1:
									raise
								elif len(l_)==1 and os.path.isdir(临时文件夹名_+'/'+l_[0]):
									临时文件夹名_=临时文件夹名_+'/'+l_[0]
								else:
									break
							zf.close()
							os.remove(临时文件名)
							if __类型__[0]in[0,2]:
								for i in os.listdir():
									if os.path.isdir(i):
										if i not in[临时文件夹名.split('/')[1],数据文件目录.split('/')[0]]:
											shutil.rmtree(i)
									if os.path.isfile(i):
										os.remove(i)
								for i in os.listdir(临时文件夹名_):
									shutil.move(临时文件夹名_+'/'+i,目录名)
								shutil.rmtree(临时文件夹名)
							elif __类型__[0]==1:
								执行='move /y "_替换_临时文件名_\\*" "_替换_文件名_" && rd /s /q _替换_临时文件名_ & pause & "_替换_文件名_\\s.exe"'.replace('_替换_文件名_',目录名.replace('/','\\')).replace('_替换_临时文件名_',临时文件夹名_.replace('/','\\'))
								print()
								按任意键继续('将要关闭并更新,',提示信息_3='开始')
								# ping 0.0.0.0 用于延时 , 不使用 timeout 是因为 在某些精简系统中会被删除
								os.system('taskkill /pid '+str(os.getpid())+' /f & ping 0.0.0.0 -n 5 > nul & '+执行)
								#os.system('start cmd.exe /c echo 更新文件... ^& ping 127.0.0.2 -n 2 ^>nul ^& '+执行.replace('^','^^').replace('&','^&'))
								sys.exit()
							

						else:
							print('文件不存在或已损坏')
					elif __类型__[1]==1:#单文件
						if __类型__[0]==1:#EXE , windows
							#os.system('start cmd.exe /c echo 更新文件...^&ping 127.0.0.2 -n 2 ^>nul ^&del "_替换_文件名_" ^& move "_替换_临时文件名_" "_替换_文件名_" ^& pause ^& "_替换_文件名_"'.replace('_替换_文件名_',文件名).replace('_替换_临时文件名_',临时文件名))
							执行='move /y "_替换_临时文件名_" "_替换_文件名_" & pause & "_替换_文件名_"'.replace('_替换_文件名_',文件名.replace('/','\\')).replace('_替换_临时文件名_',临时文件名.replace('/','\\'))
							print()
							按任意键继续('将要关闭并更新,',提示信息_3='开始')
							#os.system('start cmd.exe /c echo 更新文件... ^& ping 127.0.0.2 -n 2 ^>nul ^& '+执行.replace('^','^^').replace('&','^&'))
							os.system('taskkill /pid '+str(os.getpid())+' /f & ping 0.0.0.0 -n 5 > nul & '+执行)
							sys.exit()
						if __类型__[0]in[0,2]:#源码 , (ELF , linux)
							#可能未完成,没有linux的设备,不能测试
							#os.system('kill -9 '+str(os.getpid())+' & '+执行)
							os.remove(文件名)
							os.rename(临时文件名,文件名)
							#os.system('')
						#新文件名=".".join(文件名.split(".")[0:-1])+"."+i.split(".")[-1]
					
					if os.path.isfile(临时文件名):
						os.remove(临时文件名)
					#if 方式==2:
					#	os.rename(临时文件名,新文件名)
					#print('更新文件...')
					按任意键继续('更新完成,',提示信息_3='重启程序')
					清屏()
					if os.name=='posix':
						执行='kill -9 '+str(os.getpid())+' & '
					elif os.name=='nt':
						执行='taskkill /pid '+str(os.getpid())+' /f & '
					os.system(执行+sys.executable+' '+sys.argv[0])
					#按任意键继续('更新完成,请重新打开.',提示信息_3='退出')
					#os.system("start "+新文件名.split("\\")[-1])
					sys.exit()
				else:
					print('更新失败')
					按任意键继续()
		else:
			print('没有更新')
			检查更新_状态=2
			按任意键继续()
	else:
		print('获取更新失败')
		检查更新_状态=3
		按任意键继续()


#教程_阶段=1
def 教程():
	global 启用提示
	if 教程_阶段<=1:
		配置['教程_阶段']=1
		写入配置()
		清屏()
		print('1\t教程>选项\n选项及进入选项\n行首为一个冒号 ":" 即为需要选择,就像最下面这样\n输入选项前的序号并按回车键(Enter)即可选择并进入\n尝试进入第一个选项\n\n1.这是一个选项\n2.退出\n\n↓下面这个冒号就是需要选择')
		while 1:
			输入=input(':')
			if 输入 in['2','','`']:
				return
				sys.exit()
			elif 输入=='1':
				break
		清屏()
		print('2\t教程>选项>选项1\n返回上一级\n在大多数情况下,不输入任何字符并按 Enter键 即可回到上一级\n尝试回到上一级\n\n<没有选项>\n')
		while 1:
			输入=input(':')
			if 输入 in['','`']:
				break
		清屏()
		print('3\t教程>选项\n另一种方法返回上一级\n在几乎所有情况下,输入 " ` " (通常位于键盘左上角的 ESC键 正下方.注意使用英文输入法或半角字符,不要输入全角的 " · " )\n并按 Enter键 即可回到上一级\n尝试使用该方式回到上一级\n\n<没有选项>\n')
		while 1:
			输入=input(':')
			if 输入 in['`']:
				break
		配置['教程_阶段']=2
		写入配置()
	清屏()
	print('4\t教程\n退出\n在某些情况下,需要快速地退出,可直接关闭窗口,或者按 Ctrl-C 组合 来退出\n尝试退出\n\n1.尝试在普通情况下退出\n2.尝试在半卡死状态下退出\n9.不尝试,继续教程\n')
	while 1:
		输入=input(':')
		if 输入 in['`']:
			break
		elif 输入=='1':
			print('现在已进入死循环,尝试用Ctrl-C来退出')
			while 1:
				time.sleep(1)
		elif 输入=='2':
			print('现在正访问一个无法到达的地址,尝试按Ctrl-C来退出(卡死后按这些键可能不会立即退出,需要等待几秒,或者直接关窗口)')
			while 1:
				try:
					request.urlopen('http://127.0.0.2:5275/')
				except KeyboardInterrupt:
					raise
				except:
					pass
		elif 输入=='9':
			break
	清屏()
	print('5\t教程\n教程已结束\n若之后还想温故,可到 其他>温故教程 以再次进行教程\n在本次退出前,使用功能会有提示.若之后还想看到提示,可到 其他>启用提示 以再次打开提示')
	启用提示=True
	配置['教程_阶段']=0
	写入配置()
	按任意键继续()

	
	
	
	

启用提示=False

总信息='smaqjypt 版本:'+str(__版本__)+'\n\nHello, World\n\nGithub: https://github.com/xzx482/smaqjypt_\nWebsite: https://smaqjypt.github.xzx482.ml'

if __name__=='__main__':
	清屏()
	print(总信息)
	try:检查更新()
	except:pass
	#time.sleep(2)
	#启动http服务器()
	#登录()
	#if 1:
	try:
		if 初次使用:
			输入=input('这可能是初次使用,需要教程?(Y/n):')
			if 输入 in['y','Y']:
				教程()
			elif 输入=="g":
				清屏()
				检查更新_2()
		elif 教程_阶段>0:
			教程未完成提示='上次的教程未结束,是否继续?\n1.继续\n2.下次再提醒\n3.不再需要教程'
			print(教程未完成提示)
			while 1:
				输入=input(':')
				if 输入=='1':
					教程()
					break
				elif 输入=='2':
					break
				elif 输入 in['3','`','']:
					配置['教程_阶段']=0
					写入配置()
					break
				elif 输入=="g":
					清屏()
					检查更新_2()
					清屏()
					print(教程未完成提示)

		路径=[]
		while 1:
			清屏()
			路径=路径[:0]
			路径.append("smaqjypt")
			主界面=True
			print('>'.join(路径)+" 版本:"+str(__版本__)+"\n1.手动输入用户名密码自动完成\n2.手动输入用户名密码手动选择完成\n3.使用用户名密码表完成\n4.使用已保存的用户名表完成\n5.完成管理员名下所有学生作业\n6.用户账号管理\n9.其他")
			检查更新_状态!=2 and 检查更新_信息[检查更新_状态]()
			输入_=input(':')
			主界面=False
			if 输入_==""or"`"in 输入_:
				break
			elif 输入_=="g":
				清屏()
				路径=路径[:1]
				路径.append("检查更新")
				print('>'.join(路径))
				检查更新_2()
			elif 输入_=="1":
				清屏()
				路径=路径[:1]
				路径.append("自动完成")
				print('>'.join(路径))
				if 启用提示:
					print('输入学生的账号密码(已登录过的或密码为"123456"的可不输密码),即可完成该学生的所有作业')
				try:
					while(1):
						自动完成(登录())
				except 返回:
					continue

			elif 输入_=="2":
				清屏()
				路径=路径[:1]
				路径.append("手动完成")
				if 启用提示:
					print('>'.join(路径))
					print('输入学生的账号密码(已登录过的或密码为"123456"的可不输密码),即可显示该学生的作业,输入作业id即可完成该作业')
					按任意键继续()
				try:
					while(1):
						清屏()
						print('>'.join(路径))
						显示作业列表(登录(),路径)
				except 返回:
					continue
			elif 输入_=="3":
				清屏()
				路径=路径[:1]
				路径.append("批量完成输入")
				print('>'.join(路径))
				if 启用提示:
					print('批量完成学生作业\n用户名和密码之间用半角冒号":"分开(比如张三的账号是"zhangsan2333",密码是"234567"则这样写:"zhangsan2333:234567");\n若没有更改密码可不需要冒号(比如张三的账号是"zhangsan2333",密码是默认的"123456"则可以只写账号:"zhangsan2333");\n每行一个账号(和密码),全部输入完后,再输入一个空行(即不输入任何内容再按一次回车)就可以开始了;\n全部尝试后,若有密码不正确,会显示出来;\n输入的表会保存在"'+用户表文件目录+'",以便之后使用;\n可以开始输入了')
				#print('请输入:')
				表={}
				while 1:
					输入=input(">")
					if 输入 and "`"not in 输入:
						if ":"in 输入:
							用户名_,密码_=输入.split(":",1)
						else:
							用户名_=输入
							密码_=""
						表[用户名_]=密码_
					else:
						break
				if 表 and "`"not in 输入:
					print("输入结束")
					批1=批量完成()
					批1.添加用户(表)
					批1.开始()
					批1.显示()
					批1.打印未完成()
					按任意键继续()
				else:
					continue
			elif 输入_=="4":
				清屏()
				路径=路径[:1]
				路径.append("批量完成已保存")
				print('>'.join(路径))
				if 启用提示:
					print('批量完成学生作业,使用已保存的用户表,用户表在"'+用户表文件目录+'"中,可来自"使用用户名密码表完成""完成管理员名下所有学生作业"中保存的表,也可自行保存txt格式的文本到该目录下(注意编码是"UTF-8",一行一个账号,不能有密码,需提前登录并保存用户信息)')
				#while 1:
				用户表表=os.listdir(用户表文件目录)
				用户表表_=[]
				for i in 用户表表:
					if i.split(".")[-1]=="txt":
						用户表表_.append(i)
				if not 用户表表_:
					print("没有已保存的用户名表")
					按任意键继续()
					continue
				用户表表=用户表表_
				for i in range(len(用户表表)):
					print(str(i+1)+":"+用户表表[i][0:-4])
				输入=input(':')
				#if(not 输入):
				#	break
				文件名=None
				try:
					输入_数字=int(输入)
					if 0<输入_数字 and 输入_数字<=len(用户表表):
						文件名=用户表表[输入_数字-1]
					else:
						raise BaseException
				except:
					if 输入 and 输入 in 用户表表:
						文件名=输入
					elif 输入+".txt" in 用户表表:
						文件名=输入+".txt"
				if 文件名:
					表={}
					try:
						with open(用户表文件目录+文件名,"r") as f:表_=f.read()
						for i in 表_.split("\n"):
							if i:
								表[i]=""
					except:
						print("错误:\""+用户表文件目录+文件名+"\"读取错误")

					if 表:
						批1=批量完成()
						批1.添加用户(表)
						批1.开始(False)
						批1.显示()
						批1.打印未完成()
						按任意键继续()
				
			elif 输入_=="5":
				清屏()
				路径=路径[:1]
				路径.append("批量完成管理员")
				print('>'.join(路径))
				if 启用提示:
					print('输入管理员的账号和密码,即可自动完成其名下所有学生的作业')
				try:
					完成管理员名下学生作业(登录(),路径)
					按任意键继续()
				except 返回:
					continue
			elif 输入_=="6":
				while 1:
					清屏()
					路径=路径[:1]
					路径.append("用户账号管理")
					print('>'.join(路径)+'\n1.所有账号\n2.更新用户数据\n3.删除非学生账号\n4.删除用户数据备份文件')
					输入=input(':')
					if 输入==''or"`"in 输入:
						break
					elif 输入=='1':
						while 1:
							退出=False
							路径=路径[:2]
							路径.append("所有账号")
							清屏()
							print('>'.join(路径))
							print('''可使用以下操作:
	-1:不保存并退出
	
	-2:保存并退出

	退出(0)(exit):退出该页面

	刷新列表(1):操作过列表后,序号可能不连续或错乱,可刷新列表

	删除(2):删除一个或多个用户
		用法:删除 <序号范围>
	
	cookie(3):输出一个用户的cookie的js设置代码,可粘贴于浏览器的开发者调试工具(F12可呼出)的控制台(Console),以直接登录而无需密码
		用法:cookie <序号>
	

	序号范围可选择单个或多个序号,起始值和结束值之间用'-'分开,如'23-58'
	多个范围用半角逗号','隔开,如'12-23,53-77'
	''')
							#print('\n-1.不保存并退出\n-2.保存并退出')
							用户数据_=copy.deepcopy(用户数据)
							用户数据_修改=False
							初次=True
							保存=False
							while 1:
								if 初次:
									输入='1'
									初次=False
								else:
									输入=input('>')
								if 输入 in['退出','exit','0','`']:
									if 用户数据_修改:
										输入=input('数据已修改,是否保存?( C(取消) / y(保存) / n(不保存) ):')
										if 输入 in['n','`']:
											pass
										elif 输入=='y':
											保存=True
										else:
											continue
									退出=True
									break
								elif 输入=='-1':
										退出=True
										break
								elif 输入=='-2':
										保存=True
										退出=True
										break
								elif 输入=='刷新列表'or 输入=='1':
									print('#	姓名	类型	账号')
									序号=0
									序号_={}
									for i in 用户数据_:
										序号+=1
										序号_[序号]=用户数据_[i][1]['UserName']
										print(str(序号)+'\t'+用户数据_[i][1]['TrueName']+'\t'+('管理员'if 用户数据_[i][1]['UserType'] else '学生')+'\t'+用户数据_[i][1]['UserName'])
								elif 输入[:3]=='删除 'or  输入[:2]=='2 ':
									输入=输入.split(' ',1)[1].replace(' ','').split(',')
									for i in 输入:
										if '-'in i:
											输入_=[]
											for i2 in i.split('-',1):
												try:
													输入_.append(int(i2))
												except ValueError:
													print('注意:"'+i2+'"不是数字,跳过"'+i+'"')
													break
											if len(输入_)!=2:
												continue
											if 输入_[0]>输入_[1]:
												print('注意:"'+str(输入_[0])+'"大于"'+str(输入_[1])+'",跳过"'+i+'"')
												continue
											for i in range(输入_[0],输入_[1]+1):
												if i in 序号_ and 序号_[i] in 用户数据_:
													del(用户数据_[序号_[i]])
													用户数据_修改=True
												else:
													print('注意:序号'+str(i)+' 不在列表中')
										else:
											try:
												i=int(i)
											except ValueError:
												print('注意:"'+i+'"不是数字,跳过"'+i+'"')
											else:
												if i in 序号_ and  序号_[i] in 用户数据_:
													del(用户数据_[序号_[i]])
													用户数据_修改=True
												else:
													print('注意:序号'+str(i)+' 不在列表中')
												
											
								elif 输入[:7]=='cookie 'or  输入[:2]=='3 ':
									输入=输入.split(' ',1)[1]
									try:
										输入=int(输入)
									except ValueError:
										print('注意:"'+输入+'"不是数字')
									else:
										if 输入 in 序号_ and  序号_[输入] in 用户数据_:
											'''
											co=['','']
											for i in 用户数据_[序号_[输入]][0].split(';'):
											
												if i[1]==' ':
													i=i[1:]
												#co+="document.cookie='"+i+"=;expires=0';"
												co[0]+="document.cookie='"+i.split('=')[0]+"=;expires=Thu, 01 Jan 1970 00:00:00 GMT';"
												co[1]+="document.cookie='"+i+";expires="+time.strftime('%a, %d %b %Y %H:%M:%S GMT',time.gmtime(time.time()+86400))+"';"
											print(co[0]+co[1]+"location.href='https://sanming.xueanquan.com/mainpage.html'")
											'''
											print('\n'
												#清除cookie
												"var keys=document.cookie.match(/[^ =;]+(?=\=)/g);var d0=new Date(0).toUTCString();"'\n'
												"for(var i = keys.length; i--;)document.cookie=keys[i]+'=0;expires='+d0;"'\n'
												#退出登录
												"$.getJSON('/LoginOutHandler.ashx?jsoncallback=?',{r:Math.random()},function(json){"'\n'
													#添加UserID
													"document.cookie='UserID="+用户数据_[序号_[输入]][1]['UserId']+";expires="+time.strftime('%a, %d %b %Y %H:%M:%S GMT',time.gmtime(time.time()+86400))+"';"'\n'
													#跳转到主页
													"location.href='https://sanming.xueanquan.com/mainpage.html'"
												"});"'\n'
											)
										
										else:
											print('注意:序号'+str(输入)+' 不在列表中')
								else:
									print('未知的操作')
							if 退出:
								if 保存:
									用户数据=用户数据_
									重写用户数据()
									按任意键继续("完成\n")
								break
								
					elif 输入=='2':
						n=1
						print()
						用户数据__={}
						for i in 用户数据:
							print('\r第'+str(n)+'个,共'+str(len(用户数据))+'个',end='',flush=True)
							用户_=用户.用户()
							try:
								用户_.登录(UserID=用户数据[i][1]['UserId'])
								用户数据_=用户_.转列表()
								用户数据__[用户数据_[1]['UserName']]=用户数据_
							except BaseException as 信息:
								print('注意: "'+用户数据[i][1]['UserName']+'"更新出错 '+repr(信息))
							n+=1
						print()
						用户数据=用户数据__
						重写用户数据()
						按任意键继续("完成\n")
					elif 输入=="3":
						print("非学生账号 包括 班主任 管理员 等 的账号")
						确认值="yqf"
						if input('输入"'+确认值+'"确认删除:')==确认值:
							print("正在删除")
							用户数据__={}
							for i in 用户数据:
								if 用户数据[i][1]['UserType']==0:
									用户数据__[i]=用户数据[i]
								else:
									print('删除了 "'+i+'"')
							用户数据=用户数据__
							重写用户数据()
							按任意键继续("已删除\n")
						else:
							按任意键继续("未删除\n")
					elif 输入=="4":
						print("")
						确认值="ydf"
						print('"用户数据备份文件" 是指 在数据文件夹( "'+数据文件目录+'" )中 文件名 以 "用户信息.json." 开头 并 以".bak"结尾 的文件')
						有删除=None
						if input('输入"'+确认值+'"确认删除:')==确认值:
							有删除=False
							文件路径=os.path.dirname(用户数据文件)
							for i in os.listdir(文件路径):
								文件名=文件路径+'/'+i
								if os.path.isfile(文件名)and i[:10]=='用户信息.json.'and i[-4:]=='.bak':
									try:
										os.remove(文件名)
										print('删除了"'+i+'"')
										有删除=True
									except:
										print('无法删除"'+i+'"')
						if 有删除 is None:
							print('未删除')
						elif 有删除 is False:
							print('没有可删除的文件')
						按任意键继续()
									

			elif 输入_=="9":
				while 1:
					清屏()
					路径=路径[:1]
					路径.append("其他")
					print('>'.join(路径)+'\n1.启用提示\n2.重温教程\n3.设置延迟\n4.模拟真实登录\n5.设置修改密码\n8.关于\n9.删除数据')
					输入=input(':')
					if 输入==''or"`"in 输入:
						break
					elif 输入=='1':
						启用提示=True
						print("提示已启用")
						time.sleep(0.4)
					elif 输入=='2':
						教程_阶段=0
						教程()
					elif 输入=='3':
						print(
							'启用延迟后,完成的效率将明显变慢,但可以减少被发现的概率\n延迟及具体延迟时间可在 "'+配置文件+'" 中找到并修改\n'
							'0为不延迟,1为模拟正常人的速度,2为比正常人慢一倍,以此类推,可为小数\n\n'
						)
						print('当前延迟: '+str(配置['延迟']))
						while 1:
							输入=input('延迟:')
							if 输入 in['','`']:
								break
							else:
								try:
									输入=float(输入)
								except ValueError:
									continue
								配置['延迟']=输入
								写入配置()
								print('延迟已设置')
								time.sleep(0.4)
								break

					elif 输入=="4":
						print(
						'登录的接口有两个,一个是旧的,一个是新的.\n'
						'奇怪的是,用了新接口登录后,仍然需要旧接口来获取用户信息,于是就直接用旧接口了\n'
						'但是,若不用新接口,管理层会发现一些人没有登录就完成了作业,即用旧接口会有问题\n'
						'用新接口需要绕弯,因此速度会减慢,并且若密码强度过低会要求修改密码\n'
						'该项也称为"假登录",因为这样登录,登录了,但没有完全登录,还要登录一遍,跟假的一样\n'
						'若不担心出问题,可关闭;若不想被发现,可打开\n\n'
						)
						print('当前状态: '+('开'if 配置['假登录']else '关'))
						while 1:
							输入=input('设置(0:关, 1:开):')
							if 输入 in['','`']:
								break
							else:
								if 输入 in ['0','1']:
									配置['假登录']={'0':False,'1':True}[输入]
									写入配置()
									print('已设置')
									time.sleep(0.4)
									break
								else:
									continue
					elif 输入=="5":
						print(
							'登录时,若使用了新的接口(旧接口可直接123456,无需修改),将会检查密码强度'
							'当密码强度不符合要求("8~20位数字与包含大小写字母的组合")时,将自动修改密码,修改的密码可自定\n'
							'密码不要设为自己的私人密码!\n'
							'\n'
						)
						print('当前密码为: '+str(配置['修改密码']))
						while 1:
							输入=input('新密码:')
							if 输入 in['','`']:
								break
							else:
								if 修改密码匹配.match(输入):
									配置['修改密码']=输入
									写入配置()
									print('新密码已设置')
									time.sleep(0.4)
									break
								else:
									print('密码不符合要求')
					elif 输入=="8":
						print(总信息)
						按任意键继续()
					elif 输入=="9":
						确认值="yqs"
						print('"数据" 是指 在数据文件夹( "'+数据文件目录+'" )及其下的所有内容')
						if input('输入"'+确认值+'"确认删除数据:')==确认值:
							print("正在删除数据",end="",flush=True)
							用户数据文件o.close()
							配置文件o.close()
							shutil.rmtree(数据文件目录)
							按任意键继续("\r已删除数据  \n")
							time.sleep(0.4)
							清屏()
							raise 强制退出
						else:
							按任意键继续("未删除数据\n")
	#try:pass
	#'''
	#except KeyboardInterrupt:
	#	if(not 安静模式):
	#		print("\n用户中断执行")
	except 强制退出:
		sys.exit()
	except(SystemExit,EOFError,KeyboardInterrupt):
		if not 写用户数据__():
			input()
	except OSError:
		etype,value,tb=traceback.sys.exc_info()
		错误信息="".join(traceback.TracebackException(type(value),value,tb,limit=None).format(chain=None))
		#print(错误.args[0])
		#if("args" in 错误.args[0]):
		print("\n"+"-"*10+"操作系统错误,错误信息如下"+"-"*10)
		print(错误信息,end="")
		print("-"*10+"操作系统错误,错误信息如上"+"-"*10)
		print("操作系统错误是无法预料的.可尝试重新运行程序,重启,使用其他设备,更换网络环境.具体可根据错误信息的最后一行来尝试解决问题")
		写用户数据__()
		按任意键继续(提示信息_3="退出")
	except:
		try:
			#错误信息="".join(traceback.StackSummary.from_list(traceback.extract_tb(*traceback.sys.exc_info()).format())
			etype,value,tb=traceback.sys.exc_info()
			错误信息="".join(traceback.TracebackException(type(value),value,tb,limit=None).format(chain=None))
			print("-"*10+"出错了,错误信息如下"+"-"*10)
			print(错误信息,end="")
			#traceback.print_exception(*traceback.sys.exc_info())
			print("-"*10+"出错了,错误信息如上"+"-"*10)
			时间=time.time()
			错误信息文件路径=错误信息文件目录+获取格式化时间()+".txt"
			try:
			#if 1:
				with open(错误信息文件路径,"w") as f:
					f.write("版本:"+str(__版本__)+"\n")
					f.write("时间:"+str(时间)+"\n")
					f.write(错误信息)
					print("错误信息已保存到\""+错误信息文件路径+"\"")
					print("若要反馈此问题,可反馈到邮箱1738078451@qq.com,标题为\"问题反馈\",在正文中描述该问题是如何发生的,并将错误信息添加到附件中,错误信息不会包括个人信息")
			except:pass
			写用户数据__()
			按任意键继续(提示信息_3="退出")
		except:
			写用户数据__()
			input("\n出错了,这是显示错误时又发生了错误,因此无法显示错误信息\n")
	#'''
